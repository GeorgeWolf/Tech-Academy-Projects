﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CS_ASP_037
{
    public class Promotion
    {
        public string PromotionalOffers { get; set; }

        public void AddPromotionalOffer() { }
        public void DiscountCar() { }
    }
}