﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACME.Marketing
{
    public class Administration
    {
        public string FormatMessage()
        {
            return "From ACME.Marketing.Administration.FormatMessage()";
        }
    }
}
