﻿// This is the click event handler for 
// button1.
$('#button1').click(function () {
    var myMessage = "button1";
    alert('Hello from: ' + myMessage);
});