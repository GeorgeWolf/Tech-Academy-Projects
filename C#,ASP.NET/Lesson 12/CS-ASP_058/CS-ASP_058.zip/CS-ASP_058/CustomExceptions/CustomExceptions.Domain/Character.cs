﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomExceptions.Domain
{
    public class Character
    {
        public string Name { get; set; }
        public int HitPoints { get; set; }
    }
}
