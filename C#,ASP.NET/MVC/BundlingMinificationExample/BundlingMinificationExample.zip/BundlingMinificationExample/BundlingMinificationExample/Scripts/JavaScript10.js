﻿// This is the click event handler for 
// button10.
$('#button10').click(function () {
    var myMessage = "button10";
    alert('Hello from: ' + myMessage);
});