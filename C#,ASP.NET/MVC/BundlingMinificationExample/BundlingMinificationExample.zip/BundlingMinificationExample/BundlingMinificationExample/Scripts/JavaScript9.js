﻿// This is the click event handler for 
// button9.
$('#button9').click(function () {
    var myMessage = "button9";
    alert('Hello from: ' + myMessage);
});