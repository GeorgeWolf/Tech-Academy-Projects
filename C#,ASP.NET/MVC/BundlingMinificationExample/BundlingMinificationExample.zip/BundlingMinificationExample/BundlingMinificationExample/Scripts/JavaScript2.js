﻿// This is the click event handler for 
// button2.
$('#button2').click(function () {
    var myMessage = "button2";
    alert('Hello from: ' + myMessage);
});