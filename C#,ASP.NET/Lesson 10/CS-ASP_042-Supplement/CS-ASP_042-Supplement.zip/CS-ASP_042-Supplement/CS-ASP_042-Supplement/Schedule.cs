﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CS_ASP_042_Supplement
{
    public class Schedule
    {
        public int DayOfWeek { get; set; }
        public double TimeBegin { get; set; }
        public double DurationInMinutes { get; set; }
    }
}