﻿// This is the click event handler for 
// button8.
$('#button8').click(function () {
    var myMessage = "button8";
    alert('Hello from: ' + myMessage);
});