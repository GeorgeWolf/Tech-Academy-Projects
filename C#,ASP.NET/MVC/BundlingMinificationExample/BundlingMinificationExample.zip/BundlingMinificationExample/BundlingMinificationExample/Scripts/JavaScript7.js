﻿// This is the click event handler for 
// button7.
$('#button7').click(function () {
    var myMessage = "button7";
    alert('Hello from: ' + myMessage);
});