﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CS_ASP_040
{
    public class Class1
    {
    }
}