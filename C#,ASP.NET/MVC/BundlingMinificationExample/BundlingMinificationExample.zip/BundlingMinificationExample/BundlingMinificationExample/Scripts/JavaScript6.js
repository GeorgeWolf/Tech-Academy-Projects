﻿// This is the click event handler for 
// button6.
$('#button6').click(function () {
    var myMessage = "button6";
    alert('Hello from: ' + myMessage);
});