﻿using System;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CS_ASP_040
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //System.Text.StringBuilder sb = new System.Text.StringBuilder();

            StringBuilder sb = new StringBuilder();

            Class1 cl = new Class1();

        }
    }
}