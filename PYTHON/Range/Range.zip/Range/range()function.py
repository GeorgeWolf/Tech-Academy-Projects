# Python:   3.6.5
#
# Author:   George Wolf (georgewolf.ot@gmail.com)
#
# Purpose:  The Tech Academy - Python Course
#           Python range() funtion Drill

for i in range(4): # 1st drill
    print(i)

print("-----")

for i in range(3,-1,-1): # 2nd drill
    print(i)

print("-----")

for i in range(8,0,-2): # 3rd drill
    print(i)
