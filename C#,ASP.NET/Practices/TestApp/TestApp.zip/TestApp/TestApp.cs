// A simple C# application.
using System;

class TestApp
{
	static void Main()
	{
		Console.WriteLine("Testing! 1, 2, 3");
	}
}

// Compiling TestApp.cs into a console application named TestApp.exe (3 ways)

// csc /target:exe TestApp.cs
// csc /t:exe TestApp.cs
// csc TestApp.cs
