﻿// This is the click event handler for 
// button4.
$('#button4').click(function () {
    var myMessage = "button4";
    alert('Hello from: ' + myMessage);
});