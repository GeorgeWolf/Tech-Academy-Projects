﻿// This is the click event handler for 
// button3.
$('#button3').click(function () {
    var myMessage = "button3";
    alert('Hello from: ' + myMessage);
});