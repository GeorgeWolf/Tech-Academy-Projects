﻿// This is the click event handler for 
// button5.
$('#button5').click(function () {
    var myMessage = "button5";
    alert('Hello from: ' + myMessage);
});